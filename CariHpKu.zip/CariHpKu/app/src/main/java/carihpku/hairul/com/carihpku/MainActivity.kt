package carihpku.hairul.com.carihpku

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       /* buAge.setOnClickListener{

        }*/
    }
    fun buFindAge(view:View) {
        val yOb:String=tvText.text.toString()
        if(yOb.toInt()==0){
            textView.text="invalid years"
            return
        }
        val tahunSkr:Int=Calendar.getInstance().get(Calendar.YEAR)
        val myAge=tahunSkr-yOb.toInt()
        val avg=myAge/yOb.toInt()
        textView.text="Your Age $myAge Years"

    }
}
